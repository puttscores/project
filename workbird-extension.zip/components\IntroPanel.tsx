import React, { useState, useEffect } from 'react';
import { Logger } from '../services/logger';

interface IntroStep {
  title: string;
  content: string;
  subtext?: string;
  items?: string[];
  required?: boolean;
}

const introSteps: IntroStep[] = [
  {
    title: "Welcome to WorkBird AI Trading",
    content: "Where AI meets trading, and your money meets... well, let's make sure it meets more money! 🚀",
    subtext: "Don't worry, our AI is probably smarter than your last trade decision (no offense)."
  },
  {
    title: "Setup Required",
    content: "Before we can start analyzing charts, we need two important things:",
    items: [
      "OpenRouter API Key - For our AI's big brain 🧠",
      "Alpaca API Keys - For the actual trading magic ✨"
    ],
    required: true
  },
  {
    title: "Risk Management",
    content: "Because YOLO is not a trading strategy",
    items: [
      "Set your maximum position size",
      "Configure stop-loss and take-profit levels",
      "Define your risk tolerance",
      "Set up trailing stops"
    ],
    required: true
  },
  {
    title: "How It Works",
    content: "Our AI Trading Assistant will:",
    items: [
      "Analyze your charts in real-time",
      "Identify patterns and trends",
      "Calculate support and resistance levels",
      "Provide trading suggestions",
      "Monitor your positions"
    ]
  },
  {
    title: "Ready to Start?",
    content: "Let's set up your trading parameters and get started!",
    subtext: "Remember: The AI is here to assist, not replace your judgment. Always do your own research."
  }
];

interface IntroPanelProps {
  onComplete: () => void;
  onSetupKeys: () => void;
  onConfigureRisk: () => void;
  hasApiKeys: boolean;
  hasRiskConfig: boolean;
}

export const IntroPanel: React.FC<IntroPanelProps> = ({
  onComplete,
  onSetupKeys,
  onConfigureRisk,
  hasApiKeys,
  hasRiskConfig
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    Logger.info('IntroPanel', 'Initializing intro panel');
  }, []);

  const handleNext = () => {
    Logger.debug('IntroPanel', `Moving to step ${currentStep + 1}`);
    if (currentStep < introSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    Logger.debug('IntroPanel', `Moving to step ${currentStep - 1}`);
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    Logger.info('IntroPanel', 'Completing intro panel');
    setIsVisible(false);
    onComplete();
  };

  const currentStepData = introSteps[currentStep];
  const canProceed = !currentStepData.required || 
    (currentStep === 1 && hasApiKeys) || 
    (currentStep === 2 && hasRiskConfig);

  if (!isVisible) return null;

  return (
    <div className="intro-panel">
      <div className="intro-content">
        <div className="step-indicator">
          {introSteps.map((_, index) => (
            <div
              key={index}
              className={`step-dot ${index === currentStep ? 'active' : ''} ${
                index < currentStep ? 'completed' : ''
              }`}
            />
          ))}
        </div>

        <h2>{currentStepData.title}</h2>
        <p className="content">{currentStepData.content}</p>
        
        {currentStepData.subtext && (
          <p className="subtext">{currentStepData.subtext}</p>
        )}
        
        {currentStepData.items && (
          <ul className="items-list">
            {currentStepData.items.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        )}

        {currentStep === 1 && !hasApiKeys && (
          <button 
            onClick={onSetupKeys}
            className="setup-button"
          >
            Set Up API Keys
          </button>
        )}

        {currentStep === 2 && !hasRiskConfig && (
          <button 
            onClick={onConfigureRisk}
            className="setup-button"
          >
            Configure Risk Parameters
          </button>
        )}

        <div className="controls">
          {currentStep > 0 && (
            <button 
              onClick={handlePrevious}
              className="nav-button previous"
            >
              <i className="fas fa-arrow-left" /> Previous
            </button>
          )}
          
          <button
            onClick={handleNext}
            className={`nav-button next ${!canProceed ? 'disabled' : ''}`}
            disabled={!canProceed}
          >
            {currentStep < introSteps.length - 1 ? (
              <>
                Next <i className="fas fa-arrow-right" />
              </>
            ) : (
              <>
                Get Started <i className="fas fa-rocket" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default IntroPanel;
