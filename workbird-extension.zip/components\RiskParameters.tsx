import React, { useState, useEffect } from 'react';
import { Logger } from '../services/logger';
import { RiskParameters } from '../services/analysis';

interface RiskParametersPanelProps {
  onUpdate: (params: RiskParameters) => void;
  initialParams?: RiskParameters;
}

const defaultRiskParams: RiskParameters = {
  account: {
    mode: 'paper',
    maxPositionSize: 1000,
    maxDrawdown: 10,
    buyingPower: 10000
  },
  trading: {
    maxLossPerTrade: 2,
    stopLossPercentage: 2,
    takeProfitRatio: 2,
    maxOpenPositions: 5,
    trailingStopEnabled: true,
    trailingStopDistance: 1
  },
  strategy: {
    minConfidenceScore: 70,
    requiredSignals: 2,
    timeframePreference: ['1h', '4h', '1d'],
    patternWeight: 0.4,
    indicatorWeight: 0.6
  }
};

export const RiskParametersPanel: React.FC<RiskParametersPanelProps> = ({
  onUpdate,
  initialParams = defaultRiskParams
}) => {
  const [params, setParams] = useState<RiskParameters>(initialParams);
  const [expanded, setExpanded] = useState({
    account: true,
    trading: true,
    strategy: true
  });

  useEffect(() => {
    Logger.debug('RiskParameters', 'Initializing with params', initialParams);
  }, []);

  const handleChange = (
    section: keyof RiskParameters,
    field: string,
    value: string | number | boolean | string[]
  ) => {
    Logger.debug('RiskParameters', `Updating ${section}.${field}`, { value });
    
    setParams(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleSubmit = () => {
    Logger.info('RiskParameters', 'Submitting updated parameters');
    onUpdate(params);
  };

  const toggleSection = (section: keyof typeof expanded) => {
    setExpanded(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  return (
    <div className="risk-parameters-panel">
      {/* Account Settings */}
      <div className="section">
        <div 
          className="section-header" 
          onClick={() => toggleSection('account')}
        >
          <h3>Account Settings</h3>
          <i className={`fas fa-chevron-${expanded.account ? 'up' : 'down'}`} />
        </div>
        
        {expanded.account && (
          <div className="section-content">
            <div className="form-group">
              <label>Trading Mode</label>
              <select
                value={params.account.mode}
                onChange={(e) => handleChange('account', 'mode', e.target.value as 'paper' | 'live')}
              >
                <option value="paper">Paper Trading</option>
                <option value="live">Live Trading</option>
              </select>
            </div>

            <div className="form-group">
              <label>Max Position Size ($)</label>
              <input
                type="number"
                value={params.account.maxPositionSize}
                onChange={(e) => handleChange('account', 'maxPositionSize', Number(e.target.value))}
                min="0"
              />
            </div>

            <div className="form-group">
              <label>Max Drawdown (%)</label>
              <input
                type="number"
                value={params.account.maxDrawdown}
                onChange={(e) => handleChange('account', 'maxDrawdown', Number(e.target.value))}
                min="0"
                max="100"
              />
            </div>

            <div className="form-group">
              <label>Buying Power ($)</label>
              <input
                type="number"
                value={params.account.buyingPower}
                onChange={(e) => handleChange('account', 'buyingPower', Number(e.target.value))}
                min="0"
              />
            </div>
          </div>
        )}
      </div>

      {/* Trading Settings */}
      <div className="section">
        <div 
          className="section-header" 
          onClick={() => toggleSection('trading')}
        >
          <h3>Trading Rules</h3>
          <i className={`fas fa-chevron-${expanded.trading ? 'up' : 'down'}`} />
        </div>
        
        {expanded.trading && (
          <div className="section-content">
            <div className="form-group">
              <label>Max Loss Per Trade (%)</label>
              <input
                type="number"
                value={params.trading.maxLossPerTrade}
                onChange={(e) => handleChange('trading', 'maxLossPerTrade', Number(e.target.value))}
                min="0"
                max="100"
                step="0.1"
              />
            </div>

            <div className="form-group">
              <label>Stop Loss (%)</label>
              <input
                type="number"
                value={params.trading.stopLossPercentage}
                onChange={(e) => handleChange('trading', 'stopLossPercentage', Number(e.target.value))}
                min="0"
                max="100"
                step="0.1"
              />
            </div>

            <div className="form-group">
              <label>Take Profit Ratio</label>
              <input
                type="number"
                value={params.trading.takeProfitRatio}
                onChange={(e) => handleChange('trading', 'takeProfitRatio', Number(e.target.value))}
                min="0"
                step="0.1"
              />
            </div>

            <div className="form-group">
              <label>Max Open Positions</label>
              <input
                type="number"
                value={params.trading.maxOpenPositions}
                onChange={(e) => handleChange('trading', 'maxOpenPositions', Number(e.target.value))}
                min="1"
              />
            </div>

            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={params.trading.trailingStopEnabled}
                  onChange={(e) => handleChange('trading', 'trailingStopEnabled', e.target.checked)}
                />
                Enable Trailing Stop
              </label>
            </div>

            {params.trading.trailingStopEnabled && (
              <div className="form-group">
                <label>Trailing Stop Distance (%)</label>
                <input
                  type="number"
                  value={params.trading.trailingStopDistance}
                  onChange={(e) => handleChange('trading', 'trailingStopDistance', Number(e.target.value))}
                  min="0"
                  step="0.1"
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Strategy Settings */}
      <div className="section">
        <div 
          className="section-header" 
          onClick={() => toggleSection('strategy')}
        >
          <h3>Strategy Parameters</h3>
          <i className={`fas fa-chevron-${expanded.strategy ? 'up' : 'down'}`} />
        </div>
        
        {expanded.strategy && (
          <div className="section-content">
            <div className="form-group">
              <label>Minimum Confidence Score (%)</label>
              <input
                type="number"
                value={params.strategy.minConfidenceScore}
                onChange={(e) => handleChange('strategy', 'minConfidenceScore', Number(e.target.value))}
                min="0"
                max="100"
              />
            </div>

            <div className="form-group">
              <label>Required Signals</label>
              <input
                type="number"
                value={params.strategy.requiredSignals}
                onChange={(e) => handleChange('strategy', 'requiredSignals', Number(e.target.value))}
                min="1"
              />
            </div>

            <div className="form-group">
              <label>Timeframe Preference</label>
              <select
                multiple
                value={params.strategy.timeframePreference}
                onChange={(e) => {
                  const selected = Array.from(e.target.selectedOptions, option => option.value);
                  handleChange('strategy', 'timeframePreference', selected);
                }}
              >
                <option value="1m">1 Minute</option>
                <option value="5m">5 Minutes</option>
                <option value="15m">15 Minutes</option>
                <option value="1h">1 Hour</option>
                <option value="4h">4 Hours</option>
                <option value="1d">1 Day</option>
              </select>
            </div>

            <div className="form-group">
              <label>Pattern Weight</label>
              <input
                type="number"
                value={params.strategy.patternWeight}
                onChange={(e) => handleChange('strategy', 'patternWeight', Number(e.target.value))}
                min="0"
                max="1"
                step="0.1"
              />
            </div>

            <div className="form-group">
              <label>Indicator Weight</label>
              <input
                type="number"
                value={params.strategy.indicatorWeight}
                onChange={(e) => handleChange('strategy', 'indicatorWeight', Number(e.target.value))}
                min="0"
                max="1"
                step="0.1"
              />
            </div>
          </div>
        )}
      </div>

      <div className="actions">
        <button onClick={handleSubmit} className="save-button">
          Save Parameters
        </button>
      </div>
    </div>
  );
};

export default RiskParametersPanel;
