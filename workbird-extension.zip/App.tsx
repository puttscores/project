import React, { useState, useEffect } from 'react';
import { Logger } from './services/logger';
import { RiskParameters } from './services/analysis';
import IntroPanel from './components/IntroPanel';
import RiskParametersPanel from './components/RiskParameters';

interface AppState {
  showIntro: boolean;
  hasApiKeys: boolean;
  hasRiskConfig: boolean;
  expandedSections: {
    settings: boolean;
    analysis: boolean;
    strategy: boolean;
    trading: boolean;
  };
  riskParameters: RiskParameters;
}

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    showIntro: true,
    hasApiKeys: false,
    hasRiskConfig: false,
    expandedSections: {
      settings: true,
      analysis: true,
      strategy: true,
      trading: true
    },
    riskParameters: {
      account: {
        mode: 'paper',
        maxPositionSize: 1000,
        maxDrawdown: 10,
        buyingPower: 10000
      },
      trading: {
        maxLossPerTrade: 2,
        stopLossPercentage: 2,
        takeProfitRatio: 2,
        maxOpenPositions: 5,
        trailingStopEnabled: true,
        trailingStopDistance: 1
      },
      strategy: {
        minConfidenceScore: 70,
        requiredSignals: 2,
        timeframePreference: ['1h', '4h', '1d'],
        patternWeight: 0.4,
        indicatorWeight: 0.6
      }
    }
  });

  useEffect(() => {
    Logger.info('App', 'Initializing application');
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const result = await chrome.storage.local.get([
        'openrouterApiKey',
        'alpacaApiKey',
        'alpacaSecretKey',
        'riskParameters'
      ]);

      const hasKeys = !!(result.openrouterApiKey && result.alpacaApiKey && result.alpacaSecretKey);
      const hasRisk = !!result.riskParameters;

      setState(prev => ({
        ...prev,
        hasApiKeys: hasKeys,
        hasRiskConfig: hasRisk,
        showIntro: !hasKeys || !hasRisk,
        riskParameters: result.riskParameters || prev.riskParameters
      }));

      Logger.debug('App', 'Settings loaded', { hasKeys, hasRisk });
    } catch (error) {
      Logger.error('App', 'Failed to load settings', error);
    }
  };

  const handleSetupComplete = () => {
    Logger.info('App', 'Setup completed');
    setState(prev => ({ ...prev, showIntro: false }));
  };

  const handleSetupKeys = () => {
    Logger.debug('App', 'Opening API key setup');
    setState(prev => ({
      ...prev,
      expandedSections: { ...prev.expandedSections, settings: true }
    }));
  };

  const handleConfigureRisk = () => {
    Logger.debug('App', 'Opening risk configuration');
    setState(prev => ({
      ...prev,
      expandedSections: { ...prev.expandedSections, settings: true }
    }));
  };

  const handleRiskUpdate = async (params: RiskParameters) => {
    Logger.info('App', 'Updating risk parameters');
    try {
      await chrome.storage.local.set({ riskParameters: params });
      setState(prev => ({
        ...prev,
        riskParameters: params,
        hasRiskConfig: true
      }));
    } catch (error) {
      Logger.error('App', 'Failed to save risk parameters', error);
    }
  };

  const toggleSection = (section: keyof typeof state.expandedSections) => {
    setState(prev => ({
      ...prev,
      expandedSections: {
        ...prev.expandedSections,
        [section]: !prev.expandedSections[section]
      }
    }));
  };

  return (
    <div className="app-container">
      {state.showIntro && (
        <IntroPanel
          onComplete={handleSetupComplete}
          onSetupKeys={handleSetupKeys}
          onConfigureRisk={handleConfigureRisk}
          hasApiKeys={state.hasApiKeys}
          hasRiskConfig={state.hasRiskConfig}
        />
      )}

      <div className="main-content">
        <div className="section">
          <div 
            className="section-header"
            onClick={() => toggleSection('settings')}
          >
            <h3>Settings</h3>
            <i className={`fas fa-chevron-${state.expandedSections.settings ? 'up' : 'down'}`} />
          </div>
          {state.expandedSections.settings && (
            <RiskParametersPanel
              onUpdate={handleRiskUpdate}
              initialParams={state.riskParameters}
            />
          )}
        </div>

        <div className="section">
          <div 
            className="section-header"
            onClick={() => toggleSection('analysis')}
          >
            <h3>Analysis Status</h3>
            <i className={`fas fa-chevron-${state.expandedSections.analysis ? 'up' : 'down'}`} />
          </div>
          {state.expandedSections.analysis && (
            <div className="section-content">
              <p id="status">Stopped</p>
              <button id="toggleAnalysis">Start Analysis</button>
              <p id="tokenCost">Token Cost: $0.00</p>
            </div>
          )}
        </div>

        <div className="section">
          <div 
            className="section-header"
            onClick={() => toggleSection('strategy')}
          >
            <h3>Strategy Monitor</h3>
            <i className={`fas fa-chevron-${state.expandedSections.strategy ? 'up' : 'down'}`} />
          </div>
          {state.expandedSections.strategy && (
            <div className="monitor-panel">
              {/* Strategy monitor content */}
            </div>
          )}
        </div>

        <div className="section">
          <div 
            className="section-header"
            onClick={() => toggleSection('trading')}
          >
            <h3>Trade History</h3>
            <i className={`fas fa-chevron-${state.expandedSections.trading ? 'up' : 'down'}`} />
          </div>
          {state.expandedSections.trading && (
            <div id="tradeHistoryLog" className="section-content">
              {/* Trade history content */}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
