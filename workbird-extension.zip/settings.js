document.addEventListener('DOMContentLoaded', () => {
  // Get DOM elements
  const openrouterKeyInput = document.getElementById('openrouterKey');
  const alpacaKeyInput = document.getElementById('alpacaKey');
  const alpacaSecretInput = document.getElementById('alpacaSecret');
  const modelSelect = document.getElementById('modelSelect');
  const autoTradingToggle = document.getElementById('autoTrading');
  const saveButton = document.getElementById('saveSettings');
  const validationStatus = document.querySelector('.validation-status');
  const validationBanner = document.querySelector('.validation-banner');
  const toggleVisibilityButtons = document.querySelectorAll('.toggle-visibility');

  // Validation state
  let hasValidKeys = false;

  function validateKeys() {
    const hasOpenRouter = !!openrouterKeyInput.value.trim();
    const hasAlpaca = !!alpacaKeyInput.value.trim() && !!alpacaSecretInput.value.trim();
    hasValidKeys = hasOpenRouter && hasAlpaca;

    // Update UI based on validation
    validationStatus.style.display = hasValidKeys ? 'none' : 'flex';
    validationBanner.classList.toggle('hidden', hasValidKeys);
    autoTradingToggle.disabled = !hasValidKeys;

    // Update input field states
    [openrouterKeyInput, alpacaKeyInput, alpacaSecretInput].forEach(input => {
      const field = input.closest('.input-field');
      const message = field.querySelector('.validation-message');
      
      if (!input.value.trim()) {
        field.classList.add('error');
        message.textContent = 'This field is required';
      } else {
        field.classList.remove('error');
        message.textContent = '';
      }
    });

    return hasValidKeys;
  }

  // Handle password visibility toggle
  toggleVisibilityButtons.forEach(button => {
    button.addEventListener('click', () => {
      const input = button.parentElement.querySelector('input');
      const icon = button.querySelector('i');
      
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
      }
    });
  });

  // Helper function to determine if we're running in Chrome extension context
  const isExtensionContext = function() {
    return typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  };

  // Storage wrapper to handle both extension and web contexts
  const storage = {
    get: function(keys) {
      if (isExtensionContext()) {
        return new Promise(resolve => chrome.storage.local.get(keys, resolve));
      } else {
        const result = {};
        keys.forEach(key => {
          result[key] = localStorage.getItem(key);
        });
        return Promise.resolve(result);
      }
    },
    set: function(items) {
      if (isExtensionContext()) {
        return chrome.storage.local.set(items);
      } else {
        Object.entries(items).forEach(([key, value]) => {
          localStorage.setItem(key, value);
        });
        return Promise.resolve();
      }
    }
  };

  // Load saved settings
  storage.get([
    'openrouterApiKey',
    'alpacaApiKey',
    'alpacaSecretKey',
    'selectedModel',
    'autoTrading',
    'darkMode'
  ]).then(result => {
    openrouterKeyInput.value = result.openrouterApiKey || '';
    alpacaKeyInput.value = result.alpacaApiKey || '';
    alpacaSecretInput.value = result.alpacaSecretKey || '';
    modelSelect.value = result.selectedModel || modelSelect.options[0].value;
    autoTradingToggle.checked = result.autoTrading === 'true';
    
    if (result.darkMode === 'true') {
      document.body.classList.add('dark-mode');
    }

    validateKeys();
  });

  // Input validation
  [openrouterKeyInput, alpacaKeyInput, alpacaSecretInput].forEach(input => {
    input.addEventListener('input', validateKeys);
    input.addEventListener('blur', validateKeys);
  });

  // Save settings
  saveButton.addEventListener('click', () => {
    if (!validateKeys()) {
      return;
    }

    saveButton.classList.add('saving');
    saveButton.disabled = true;
    const originalContent = saveButton.innerHTML;
    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

    const settings = {
      openrouterApiKey: openrouterKeyInput.value,
      alpacaApiKey: alpacaKeyInput.value,
      alpacaSecretKey: alpacaSecretInput.value,
      selectedModel: modelSelect.value,
      autoTrading: autoTradingToggle.checked
    };

    storage.set(settings)
      .then(() => {
        if (isExtensionContext()) {
          return chrome.runtime.sendMessage({
            type: 'settingsUpdated',
            settings
          });
        }
      })
      .then(() => {
        // Show success state
        saveButton.innerHTML = '<i class="fas fa-check"></i> Saved!';
        saveButton.style.backgroundColor = 'var(--success-color)';
      })
      .catch(error => {
        // Show error state
        saveButton.innerHTML = '<i class="fas fa-times"></i> Error!';
        saveButton.style.backgroundColor = 'var(--error-color)';
        console.error('Failed to save settings:', error);
      })
      .finally(() => {
        // Reset button state
        setTimeout(() => {
          saveButton.classList.remove('saving');
          saveButton.disabled = false;
          saveButton.innerHTML = originalContent;
          saveButton.style.backgroundColor = '';
        }, 2000);
      });
  });
});
